
public abstract class AbstractShape implements Shape{
	/**
	 * The method compares the two shapes, first by area, then by perimeter,
	 * and finally by type.
	 * @param other
	 * @return A negative integer if this shape is smaller, 0 if they are equal,
	 * and a positive integer if this shape is bigger.
	 */
	public int compareTo(Shape other) {
		if(getArea() < other.getArea()) {
			return -1;
		}else if (getArea() > other.getArea()) {
			return 1;
		}else {
			if(getPerimeter() < other.getPerimeter()) {
				return -1;
			}else if(getPerimeter() > other.getPerimeter()) {
				return 1;
			}else {
				return getType().compareTo(other.getType());
			}
		}
	}
}
