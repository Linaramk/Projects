
/**
 * This class extends AbstractShape and represents a Circle.
 * @author Linara Abdyzhaparova
 *
 */
public class Circle extends AbstractShape{
	private Point myCenter;
	private int myRadius;
	
	
	/**
	 * Creates a Circle with center 0,0 and radius 0
	 */
	public Circle() {
		myCenter = new Point();
		myRadius = 0;
	}
	
	/**
	 * Creates a Circle with the given center and radius
	 * 
	 * @param theCenter
	 * @param theRadius
	 */
	public Circle(Point theCenter, int theRadius) {
		myCenter = theCenter;
		myRadius = theRadius;
	}
	
	/**
	 * The method return the type of shape
	 * @return the type of shape in string format
	 */
	public String getType() {
		return "Circle";
	}
	
	/**
	 * The method returns the perimeter of the shape
	 * @return the perimeter of the shape
	 */
	public double getPerimeter() {
		return 2 * Math.PI * myRadius; 
	}
	
	/**
	 * The method returns the area of the shape
	 * @return the area of the shape
	 */
	public double getArea() {
		return Math.PI * myRadius * myRadius;
	}
	
	/**
	 * Returns a string representation of the shape
	 */
	/** @return a string representation of the shape */
	public String toString() {
		return "{Type=" + getType() + ", Center=" + myCenter + ", Radius=" 
				+ myRadius + "}";
	}
	
}
