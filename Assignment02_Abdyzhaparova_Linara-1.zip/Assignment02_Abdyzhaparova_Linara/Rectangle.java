
/**
 * This class extends AbstractShape and represents a Rectangle.
 * @author Linara Abdyzhaparova
 *
 */
public class Rectangle extends AbstractShape{
	private Point myTopLeft; // the top-left point of the rectangule
	private Point myBottomRight; // the bottom-right point of the rectangule 
	
	
	/**
	 * Creates a Rectangle with all four points set to 0,0
	 */
	public Rectangle() {
		myTopLeft = new Point();
		myBottomRight = new Point();
	}
	
	/**
	 * Creates a Rectangle with the given points
	 * @param theTopLeft
	 * @param theBottomRight
	 */
	public Rectangle(Point theTopLeft, Point theBottomRight) {
		myTopLeft = theTopLeft;
		myBottomRight = theBottomRight;
	}
	
	/**
	 * The method return the type of shape
	 * @return the type of shape in string format
	 */
	public String getType() {
		return "Rectangle";
	}
	
	/**
	 * The method returns the perimeter of the shape
	 * @return the perimeter of the shape
	 */
	public double getPerimeter() {
		return Math.abs(myBottomRight.getX() - myTopLeft.getX()) * 2 + /**length of the rectangule */
				Math.abs(myTopLeft.getY() - myBottomRight.getY()) * 2; /** width of the rectangule */
	}
	
	/**
	 * The method returns the area of the shape
	 * @return the area of the shape
	 */
	public double getArea() {
		return Math.abs(myBottomRight.getX() - myTopLeft.getX()) *
				Math.abs(myTopLeft.getY() - myBottomRight.getY());
	}
	
	/**
	 * Returns a string representation of the shape
	 */ 
	/**  @return a string representation of the shape */
	public String toString() {
		return "{Type=" + getType() + ", TopLeft=" + myTopLeft + ", BottomRight=" 
				+ myBottomRight + "}";
	}
	
}
