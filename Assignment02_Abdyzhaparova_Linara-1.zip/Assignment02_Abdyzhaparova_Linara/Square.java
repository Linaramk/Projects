
/**
 * This class extends Rectangle and represents a Square.
 * @author Linara Abdyzhaparova
 *
 */
public class Square extends Rectangle{
	
	/**
	 * Creates a Square with all four points set to 0,0
	 */
	/** default constructor; empty because inherits from Rectangule.java */
	/** super is used because inherited from Rectangule.java */
	public Square() {
		super();
	}
	
	/** constructor with parameters */
	/**
	 * Creates a Square with the given top left corner and the length, the two points of the square that we use to find area & perimeter.
	 * @param theTopLeft
	 * @param length
	 */
	public Square(Point theTopLeft, int length) {
		super(theTopLeft, new Point(theTopLeft.getX() + length, 
				theTopLeft.getY() - length));
	}
	
	/**
	 * The method return the type of shape
	 * @return the type of shape in string format
	 */
	public String getType() {
		return "Square";
	}
	
}
