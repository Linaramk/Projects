/**
 * This class extends AbstractShape and represents a triangle.
 * @author Linara Abdyzhaparova
 *
 */
public class Triangle extends AbstractShape{
	// a point object representing the triangle's first point
	private Point myPoint1;
	// a point object representing the triangle's second point
	private Point myPoint2;
	// a point object representing the triangle's
	private Point myPoint3;
	
	/**
	 * Creates a triangle with the given points
	 * @param thePoint1
	 * @param thePoint2
	 * @param thePoint3
	 */
	public Triangle(Point thePoint1, Point thePoint2, Point thePoint3) {
		this.myPoint1 = thePoint1;
		this.myPoint2 = thePoint2;
		this.myPoint3 = thePoint3;
	}
	
	/**
	 * Creates a triangle with all three points set to 0,0
	 */
	public Triangle() {
		myPoint1 = new Point();
		myPoint2 = new Point();
		myPoint3 = new Point();
	}
	
/**The method returns the perimeter of the shape
	 * @return the perimeter of the shape */
	public double getPerimeter() {
		return Point.calculateDistance(myPoint1, myPoint2) 
				+ Point.calculateDistance(myPoint2, myPoint3)
				+ Point.calculateDistance(myPoint1, myPoint3);
	}
	/**
	 * The method returns the area of the shape
	 * @return the area of the shape
	 * /** calculates the area by using values length1, length2, length3 */
	public double getArea() {
		double length1 = Point.calculateDistance(myPoint1, myPoint2);
		double length2 = Point.calculateDistance(myPoint2, myPoint3);
		double length3 = Point.calculateDistance(myPoint1, myPoint3);
		double s = .5 * (length1 + length2 + length3);
		return Math.sqrt(s*(s-length1)*(s-length2)*(s-length3));
	}
	/**
	 * The method return the type of shape
	 * @return the type of shape in string format
	 */
	public String getType() {
		return "Triangle";
	}
	/**
	 * Returns a string representation of the shape
	 * @return a string representation of the shape
	 */
	public String toString() {
		return "{Type=" + getType() + ", Point1=" + myPoint1 + ", Point2=" + myPoint2 +
				", Point3=" + myPoint3 + "}";
	}
	
}
