Name: Linara Abdyzhaparova
Time Estimate: 7-8 hours
Extra Credit: No
Problems:
  First I did not understand that why AbstractShape class should have one implemented method: compareTo().
Then I figured out that This is because the compareTo() method will be the same for Triangle, Square, Circle, Rectangle. 
Questions:
  None.
