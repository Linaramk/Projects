/**
 * FILL UP YOUR JAVA DOCUMENT HERE
 * @author Linara Abdyzhaparova <linara.abdyzhaparova@bellevuecollege.edu>
 */
class MathematicsRec
{
	/**
	 * The method returns a value which:
	 * - Increases each of even decimal digits of n by one
	 * - Decreases each of  odd decimal digits of n by one
	 * @param n the input decimal number (n)
	 * @return the new decimal number after digit adjustments
	 */
	public static long eduodd(long n) {
		if (n == 0) return 1;

		//if n is negative make it positive temporarily to simplify
		Boolean positive = true;
		if (n < 0) {
			positive = false;
			n *= -1;
		}
		long result = n;
		//call the recursive helper
		result += eduoddHelper(n,1);

		//if n was negative, make it negative again
		if (!positive) {
			result *= -1;
		}

		return result;
	}
	/**
	 * Helper method of eduodd which:
	 * - Takes a digit off the end of n and adds or subtracts
	 *   from the result based on whether the digit is even
	 *   or odd
	 * @param n the input decimal number (n)
	 * @param place what place in the number to add or subtract from (1s, 10s, 100s, etc)
	 * @return the new decimal number after digit adjustments
	 */
	private static long eduoddHelper(long n, long place) {
		if (n == 0) {
			return 0;
		}
		long digit = n % 10;
		if (n % 2 == 0 ) {
			return eduoddHelper(n/10, place * 10) + place;
		}
		else {
			return eduoddHelper(n/10, place * 10) - place;
		}
	}
	/**
	 * The method accepts non-negative integer and returns a value as described below
	 * @param  start is a non-negative decimal number (n)
	 * @return the value in following way:
	 * - return 1 when n = 0
	 * - return sum of fibby(floor(n/4)) and fibby(floor(3n/4)) when n > 0
	 */
	public static int fibby(int start) {
		if (start == 0) return 1;

		return fibby(start/4) + fibby(3*start/4);
	}

	/**
	 * The method prints all consecutive values of n and its fibby value
	 * @param start the lower bound (start)
	 * @param end the upper bound (end)
	 */
	public static void stg(int start, int end) {
		stgHelper(start,end,-1);
	}

	/**
	 * This helper method prints all consecutive values of n and its fibby value
	 * Skipping any lines where the fibby value matches the previous
	 * @param start the lower bound (start)
	 * @param end the upper bound (end)
	 * @param oldFib the previous fibby value
	 */
	private static void stgHelper(int start, int end, int oldFib) {
		int newFib = fibby(start);
		if (newFib == oldFib) {if (start == end) {
			return;
		}
			stgHelper(start+1, end, oldFib);
		}
		else {
			System.out.println(start + " " + newFib);

			if (start == end) {
				return;
			}
			else stgHelper(start+1,end, newFib);
		}
	}

	/**
	 * The method returns the approximate median of n
	 * @param n the array of integers
	 * @return the approximate median of n
	 */
	public static double median3(int[] n) {
		return medianHelper(n, 0, n.length);
	}

	/**
	 * the approximate median of the subarray of n from start to end -1
	 *
	 * @param n the array of integers
	 * @param start the index of the first element of the subarray
	 * @param end the index 1 higher than the last element of the subarray
	 * @return the approximate median of the subarray of n from start to end -1
	 */
	private static double medianHelper(int[] n, int start, int end) {
		int len = end - start;
		if (len == 1) return n[start];
		if (len == 2) return ((double)n[start] + n[end-1])/2;
		// if length is 3 or greater, check if it's divisible by 3
		int firstBound;
		int secondBound;
		if (len % 3 == 0) {
			firstBound = start + len/3;
			secondBound = start + 2*(len/3);
		}
		else if (len % 3 == 1) {
			firstBound = start + len/3;
			secondBound = start + 2*(len/3)+1;
		}
		else {
			firstBound = start + len/3+1;
			secondBound = start + 2*(len/3)+1;
		}
		double median1 = medianHelper(n, start, firstBound);
		double median2 = medianHelper(n, firstBound, secondBound);
		double median3 = medianHelper(n, secondBound, end);

		return findMiddleValue(median1, median2, median3);
	}

	private static double findMiddleValue(double n1, double n2, double n3) {
		if ((n1 <= n2 && n1 >= n3) ||(n1 <= n3 && n1 >= n2)) {
			return n1;
		}
		else if ((n2 <= n1 && n2 >= n3) || (n2 <= n3 && n2 >= n1)) {
			return n2;
		}
		else {
			return n3;
		}
	}

}