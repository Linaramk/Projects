Name: Linara Abdyzhaparova
Time Estimate: 7-8 hours
Extra Credit: No
Problems:
  After first submission I got feedback from professor. I did not understood how to correct my mistake, however, Tutor from academic sucess 
center explained to me and I understood.
Questions:
  None.
